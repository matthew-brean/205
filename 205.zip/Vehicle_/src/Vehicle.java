/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2019-10-11
* Created for: ICS4U
* Daily Assignment: #2-05
* Vehicle class with properties	license, colour, numDoors, speed, & maxSpeed, & protected
* methods brake & accelerate.
* 
*******************************************************************************/


import java.util.Scanner;

public class Vehicle {


	public int speed;
	private int maxSpeed;
	private int numDoors;
	private String colour;
	private String licensePlateNumber;
	
	
	protected void setSpeed(int speed){
		this.speed = speed;		
	}	
	
	protected void setMaxSpeed(int maxSpeed){
		this.maxSpeed = 120;
	}	
	
	protected void numDoors(int numDoors){
		this.numDoors = 4;
	}
	
	protected void colour(String colour){
		this.colour = colour;		
	}

	protected void licensePlateNumber(String licensePlateNumber){
		this.licensePlateNumber = licensePlateNumber;
	}	
	

	 public double Acceleration (int increase)
     {
         double Acceleration = speed + increase;
         return Acceleration;

     }
	 
	  public double Brake (int decrease)
      {
          double braking = speed - decrease;
          return braking;
      }
	

}
